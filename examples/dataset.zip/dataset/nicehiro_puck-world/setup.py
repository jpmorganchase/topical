from setuptools import setup


setup(
    name='puck_world',
    version='0.0.1',
    install_requires=['gym', 'numpy']
)