"""This package contains different object to create a gui to pick points from images."""
