from distutils.core import setup

setup(
    name='pud',
    version='0.1dev',
    packages=['pud'],
    license='Apache License 2.0',
)
