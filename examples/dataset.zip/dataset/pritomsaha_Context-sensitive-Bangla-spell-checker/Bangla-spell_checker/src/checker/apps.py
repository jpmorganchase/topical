from django.apps import AppConfig


class CheckerConfig(AppConfig):
    name = 'checker'
