from .lafusee import LaFusee


def setup(bot):
    bot.add_cog(LaFusee(bot))
