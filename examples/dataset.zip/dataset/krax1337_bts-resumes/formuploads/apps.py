from django.apps import AppConfig


class FormuploadsConfig(AppConfig):
    name = 'formuploads'
